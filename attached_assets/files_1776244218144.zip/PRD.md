# PRD — Tallinn Shore Tours
## Landing Page per Crocieristi Americani
**Versione:** 1.0 — Aprile 2026  
**Dominio principale:** tallinnshoretours.com  
**Preparato da:** Claude (Anthropic) + Domenico + Grok

---

## 1. Obiettivo del Prodotto

Creare una landing page ad alta conversione che trasformi i crocieristi americani che attraccano a Tallinn in clienti paganti di escursioni private. La pagina deve intercettare le ricerche pre-partenza (3–6 mesi prima) e convertire il traffico organico e PPC in prenotazioni dirette, bypassando gli aggregatori (Viator, ShoreExcursionsGroup) che prendono commissioni del 25–30%.

---

## 2. Target Utente

| Attributo | Dettaglio |
|---|---|
| Nazionalità | Americani (65% del traffico atteso) |
| Età | 45–70 anni |
| Comportamento | Pianificano online 3–6 mesi prima, cercano su Google Desktop |
| Pain point #1 | Paura di perdere la nave |
| Pain point #2 | Tour troppo affollati (50+ persone) |
| Pain point #3 | Itinerari fissi, nessuna flessibilità |
| Motivazione d'acquisto | Esperienza privata + garanzia rientro nave + guida locale autentica |
| Disponibilità di spesa | Premium — disposti a pagare di più per sicurezza e privacy |

---

## 3. Keyword SEO Primarie

- `tallinn shore excursion` (volume alto, intento acquisto)
- `tallinn shore tours` (volume alto, match dominio)
- `private tour tallinn cruise` (volume medio, conversione premium)
- `tallinn guaranteed ship return` (volume basso, conversione altissima)
- `best tallinn shore excursion` (volume alto, fase confronto)

---

## 4. Architettura della Pagina

### 4.1 Sezioni (ordine scrolling)

| # | Sezione | Obiettivo | CTA Primaria |
|---|---|---|---|
| 1 | Navigation | Accesso rapido + brand | Book Now |
| 2 | Hero | Catturare attenzione, comunicare valore core | Book Your Tour |
| 3 | Trust Strip | Rimuovere le 3 obiezioni principali | — |
| 4 | "Why Private" | Confronto con tour di linea | Explore Tours |
| 5 | Tour Packages | Mostrare l'offerta, trigger acquisto | Book This Tour |
| 6 | How It Works | Ridurre la frizione cognitiva | — |
| 7 | Testimonials | Social proof, fiducia | — |
| 8 | FAQ | Rispondere alle ultime obiezioni | — |
| 9 | Final CTA | Ultima chiamata all'azione | Book Now |
| 10 | Footer | Info legali + contatti | — |

### 4.2 Sezione Hero — Copy

**Headline principale:** "Your Private Tallinn. Your Rules."  
**Subheadline:** "Private shore excursions from Tallinn Cruise Port — pickup at the gangway, guaranteed return to your ship."  
**CTA primaria:** "Book Your Private Tour"  
**CTA secondaria:** "See All Tours"  
**Badge fiducia:** "Ship Return Guaranteed — or Full Refund"

### 4.3 Trust Strip — 4 garanzie
1. **Ship Return Guaranteed** — We track your ship's schedule in real time
2. **Your Group Only** — Never share your tour with strangers
3. **Expert Local Guides** — English-speaking, licensed, passionate about Tallinn
4. **Free Cancellation** — Full refund if your ship can't dock

### 4.4 Tour Packages

| Tour | Durata | Highlights | Prezzo indicativo |
|---|---|---|---|
| Medieval Highlights | 3 ore | Old Town, Toompea Castle, Alexander Nevsky Cathedral | Da $89/persona |
| Full City Explorer | 6 ore | Old Town + Kadriorg + Pirita Beach + Song Festival Grounds | Da $149/persona |
| Custom Private Tour | Flessibile | Itinerario costruito su misura per il tuo gruppo | Preventivo |

---

## 5. Specifiche Tecniche

### 5.1 Stack Tecnologico

| Componente | Scelta | Motivazione |
|---|---|---|
| Framework | **Vanilla HTML/CSS/JS** | Zero build step, compatibile Replit istantaneamente |
| Font | Google Fonts CDN | Cormorant Garamond + Figtree |
| Animazioni | CSS Keyframes + Intersection Observer API | No dipendenze JS esterne |
| Form | HTML5 nativo | Compatibile con Netlify Forms / Formspree |
| Icone | Inline SVG | Nessuna dipendenza esterna |
| Responsive | CSS Grid + Flexbox | Mobile-first |

### 5.2 File Structure (Replit)

```
tallinn-shore-tours/
├── index.html          ← Landing page completa (self-contained)
├── PRD.md              ← Questo documento
└── README.md           ← Istruzioni per Replit
```

### 5.3 Performance Target

| Metrica | Target | Perché |
|---|---|---|
| First Contentful Paint | < 1.5s | Molti utenti accedono da bordo nave con WiFi lento |
| Largest Contentful Paint | < 2.5s | Core Web Vitals Google |
| Page Size | < 150KB | Nessuna immagine esterna, solo CSS/HTML |
| Mobile Score | > 90 Lighthouse | 40% del traffico è mobile (last-minute sul telefono) |

### 5.4 SEO On-Page

- `<title>` ottimizzato per keyword primaria
- `<meta description>` 155 caratteri con CTA
- `<h1>` unico, keyword-rich
- Schema.org markup: `TouristAttraction` + `LocalBusiness`
- Open Graph per condivisione social
- Hreflang: `en-US`

---

## 6. Copy Strategy

### 6.1 Tone of Voice
- **Warm but confident** — come un amico esperto che conosce bene Tallinn
- **Reassuring first** — la prima cosa che l'americano vuole sentire è "non perderà la nave"
- **Specifico, non generico** — nomi di luoghi reali (Toompea, Kadriorg, Alexander Nevsky)
- **American English** — "harbor" non "harbour", "customize" non "customise"

### 6.2 Gerarchia dei Messaggi
1. Sei al sicuro (non perderai la nave) ← messaggio #1
2. Esperienza privata e personalizzata ← differenziazione
3. Guide locali esperte e appassionate ← credibilità
4. Prezzo competitivo vs cruise line ← valore
5. Facile da prenotare in 3 minuti ← frizione ridotta

---

## 7. Booking Form

### Campi richiesti
| Campo | Tipo | Obbligatorio |
|---|---|---|
| Ship Name | Text | Sì |
| Arrival Date | Date | Sì |
| Number of Guests | Select (1–15) | Sì |
| Tour Type | Select | Sì |
| Email Address | Email | Sì |
| Special Requests | Textarea | No |

### Comportamento form
- Validazione HTML5 nativa
- Submit verso Formspree (da configurare con email reale)
- Messaggio di conferma inline (no redirect)

---

## 8. Integrazioni Raccomandate (Post-Launch)

| Servizio | Uso | Priorità |
|---|---|---|
| **Formspree** | Gestione form booking | Alta |
| **Google Analytics 4** | Tracking conversioni | Alta |
| **Google Search Console** | SEO monitoring | Alta |
| **Facebook Pixel** | Remarketing | Media |
| **TripAdvisor Widget** | Social proof review | Media |
| **WhatsApp Button** | Contatto diretto | Bassa |

---

## 9. KPI di Successo

| KPI | Target Mese 1 | Target Mese 3 |
|---|---|---|
| Tasso di conversione form | > 2% | > 4% |
| Bounce rate | < 55% | < 45% |
| Tempo medio su pagina | > 90s | > 120s |
| Posizione Google "tallinn shore tours" | Top 20 | Top 10 |
| Prenotazioni dirette/mese | 5+ | 20+ |

---

## 10. Roadmap Post-Launch

### V1.0 (Lancio — Settimana 1–4)
- [x] Landing page single-page
- [x] Form booking funzionante
- [ ] Google Analytics 4
- [ ] Google Search Console

### V1.1 (Mese 2)
- [ ] Blog section per SEO ("Top 10 things to do in Tallinn from a cruise ship")
- [ ] TripAdvisor widget con recensioni reali
- [ ] Live chat o WhatsApp button

### V2.0 (Mese 3–6)
- [ ] Sistema di prenotazione online con calendario
- [ ] Pagamento integrato (Stripe)
- [ ] Multilingua (Inglese + Italiano + Tedesco)

---

## 11. Note per lo Sviluppo su Replit

1. Creare un nuovo Replit di tipo **"HTML/CSS/JS"** o **"Static Site"**
2. Caricare `index.html` come file principale
3. Replit servirà automaticamente la pagina sulla porta 3000
4. Per il form: creare account su **formspree.io**, ottenere endpoint e sostituire `YOUR_FORMSPREE_ID` nel codice
5. Per il dominio personalizzato: configurare `tallinnshoretours.com` nelle impostazioni Replit → Custom Domain
6. Per il deploy su Netlify (alternativa più robusta): drag & drop della cartella su netlify.com/drop

---

*Documento preparato da Claude (Anthropic) — Aprile 2026*
