# Tallinn Shore Tours — Landing Page

## 🚀 Deploy su Replit (3 minuti)

### 1. Crea il progetto
- Vai su [replit.com](https://replit.com)
- Click **"Create Repl"**
- Scegli template **"HTML, CSS, JS"**
- Nome: `tallinn-shore-tours`

### 2. Carica i file
- Elimina i file di default (`index.html`, `style.css`, `script.js`)
- Carica **`index.html`** da questo pacchetto
- Click **Run** → la pagina è live

### 3. Configura il form di prenotazione (obbligatorio)
1. Crea account gratuito su [formspree.io](https://formspree.io)
2. Crea un nuovo form → ottieni l'endpoint (es. `https://formspree.io/f/xabc1234`)
3. In `index.html`, cerca `YOUR_FORMSPREE_ID` e sostituisci con il tuo ID:
   ```
   action="https://formspree.io/f/xabc1234"
   ```
4. Tutte le prenotazioni arriveranno alla tua email

### 4. Dominio personalizzato
- In Replit: Settings → Custom Domain
- Inserisci: `tallinnshoretours.com`
- Segui le istruzioni DNS su Network Today

---

## 📁 Struttura File

```
tallinn-shore-tours/
├── index.html    ← Landing page completa (self-contained)
├── PRD.md        ← Product Requirements Document
└── README.md     ← Questo file
```

**Nota:** la landing page è un singolo file `index.html` completamente autonomo.
Nessuna dipendenza npm, nessun build step. Zero configurazione.

---

## ✏️ Personalizzazioni Rapide

### Cambiare i prezzi
Cerca nel file `index.html`:
- `$89` → prezzo Medieval Highlights
- `$149` → prezzo Full City Explorer  
- `$199` → prezzo Custom Tour

### Cambiare email di contatto
Cerca `hello@tallinnshoretours.com` e sostituisci con la tua email reale.

### Cambiare il numero di telefono
Aggiungi nel footer, sezione `.footer-contact`:
```html
<div class="footer-contact-item">
  <span>📞</span>
  <span>+372 XXX XXXX</span>
</div>
```

### Aggiungere Google Analytics
Prima di `</head>`, inserisci il codice GA4 standard.

---

## 🎨 Design System

| Token | Valore | Uso |
|---|---|---|
| `--navy` | `#0B2D3E` | Background primario, testo |
| `--gold` | `#D4941E` | Accento, CTA |
| `--cream` | `#FAF7F2` | Background body |
| Font display | Cormorant Garamond | Titoli |
| Font body | Figtree | Testo |

---

## 📊 SEO Checklist

- [x] Title tag ottimizzato
- [x] Meta description 155 char
- [x] H1 con keyword primaria
- [x] Open Graph tags
- [ ] Google Search Console → verificare dominio
- [ ] Google Analytics 4 → inserire script
- [ ] Google My Business → creare profilo operatore

---

*Tallinn Shore Tours — Aprile 2026*
